# Zwei Welten – Telegram-Abenteuer (Prototyp 0.1)

## Was enthalten ist
- `index.html`: klickbarer, mobilfreundlicher Spielprototyp mit Missionen, Entscheidungen, Erfahrungspunkten, Inventar und Nachrichtenfeld.
- Speichert den Prototyp-Spielstand lokal im Browser.
- Exportiert den lokalen Spielstand als JSON-Datei.

## Wichtig
Dies ist noch keine veröffentlichte Telegram Mini App und synchronisiert noch nicht zwischen zwei Geräten. Der lokale Speicher ist nur für den aktuellen Browser auf dem jeweiligen Gerät gedacht. Für echten gemeinsamen Fortschritt brauchen wir:
1. HTTPS-Hosting für diese Seite.
2. Telegram-Bot über @BotFather.
3. Backend/Datenbank mit gemeinsamem Spielraum und serverseitiger Prüfung der Telegram-Identität.
4. Bot-Logik für Einladungslink und Benachrichtigungen.

## Schnell testen
Öffne `index.html` in einem Browser. Auf manchen Mobilgeräten ist das Öffnen lokaler HTML-Dateien umständlich; einfacher ist ein Computer oder ein Code-Editor mit Vorschau.

## Nächster Entwicklungsschritt
Die nächste Version sollte ein gemeinsames Spielzimmer mit Einladungs-Code bekommen. Beide Spieler müssen sich per Telegram anmelden; der Server speichert Entscheidungen und vergibt Punkte, damit niemand einfach den Punktestand im Browser manipulieren kann.
